import React from 'react';
import './Heroblank.css';

const Heroblank = () => {
    return (
        <section id="bgkosong">
        <div class="container-fluid bgkosongbiru">
            <div class="row">
                <div class="col">

                </div>
            </div>
        </div>
    </section>
    )
}

export default Heroblank